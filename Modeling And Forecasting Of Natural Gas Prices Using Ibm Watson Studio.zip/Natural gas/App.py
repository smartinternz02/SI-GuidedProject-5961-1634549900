from flask import Flask,render_template,request 
import pickle
import numpy as np


model=pickle.load(open(r'D:\Natural Gas\gas.pkl','rb'))
app=Flask(__name__) 
@app.route('/')
def home():
    return render_template('index.html') 

@app.route('/pred',methods=['POST'])
def pred():
    x_test=[int(x) for x in request.form.values()]
    x_test = [np.array(x_test)]
    prediction=model.predict(x_test)
    print(prediction)
    pred=prediction[[0]]
    return render_template('index.html',prediction_text='Gas Price is {} dollors'.format(pred))
if __name__=="__main__":
    app.run(debug=True)
    


