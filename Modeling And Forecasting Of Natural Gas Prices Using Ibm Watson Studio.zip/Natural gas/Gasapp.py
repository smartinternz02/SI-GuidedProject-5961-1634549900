# -*- coding: utf-8 -*-
"""
Created on Mon Nov  1 14:36:20 2021

@author: Sahal P Najeeb
"""

from flask import Flask,render_template,request 
import pickle
import numpy as np
import requests

# NOTE: you must manually set API_KEY below using information retrieved from your IBM Cloud account.
API_KEY = "IneG5pGwPdbTCy_4Yc6M-yMgKhpmjUbiKdNJl0wHWk3P"
token_response = requests.post('https://iam.cloud.ibm.com/identity/token', data={"apikey": API_KEY, "grant_type": 'urn:ibm:params:oauth:grant-type:apikey'})
mltoken = token_response.json()["access_token"]

header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + mltoken}


#model=pickle.load(open(r'D:\Natural Gas\gas.pkl','rb'))
app=Flask(__name__) 
@app.route('/')
def home():
    return render_template('index.html') 

@app.route('/pred',methods=['POST'])
def pred():
    x_test=[int(x) for x in request.form.values()]
   # NOTE: manually define and pass the array(s) of values to be scored in the next line
    payload_scoring = {"input_data": [{"fields": [["year", "month", "day"]], "values": [x_test]}]}

    response_scoring = requests.post('https://us-south.ml.cloud.ibm.com/ml/v4/deployments/3dc3c8ed-984f-4dd4-b942-6b840df77576/predictions?version=2021-11-01&version=2021-11-01', json=payload_scoring, headers={'Authorization': 'Bearer ' + mltoken})
  
    print("Scoring response")
    pred= response_scoring.json()
    print(pred)
    
    output = pred['predictions'][0]['values'][0][0]
    print(output)
    #x_test = [np.array(x_test)]
    #prediction=model.predict(x_test)
    #print(prediction)
    #pred=prediction[[0]]
    
    return render_template('index.html',prediction_text='Gas Price is {} dollors'.format(output))
if __name__=="__main__":
    app.run(debug=True)
    


